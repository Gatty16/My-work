<?php
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$admin_no = $firstname = $middlename = $sirname = $gender = $dob =
$class = $stream = $acc_year = $por = $day_boarding = $transport_zone =
$parentname1 = $contact1 = $parentname2 = $contact2 ="";
$admin_no_err = $firstname_err = $middlename_err = $sirname_err = $gender_err = $dob =
$class = $stream_err = $acc_year_err = $por_err = $day_boarding_err = $transport_zone_err =
$parentname1_err = $contact1_err = $parentname2_err = $contact2_err ="";
 
// Processing form data when form is submitted
if(isset($_POST["id"]) && !empty($_POST["id"])){
    // Get hidden input value
    $id = $_POST["id"];
    
    // Validate school Reg
    $input_admin_no = trim($_POST["admin_no"]);
    if(empty($input_admin_no)){
        $admin_no_err = "Please enter admin_no.";
    } elseif(!filter_var($input_admin_no, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
        $admin_no_err = "Please enter a valid admin_no.";
    } else{
        $admin_no = $input_admin_no;
    }


    $input_firstname = trim($_POST["firstname"]);
    if(empty($input_firstname)){
        $firstname_err = "Please enter a first name.";
    } elseif(!filter_var($input_firstname, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
        $firstname_err = "Please enter a valid first name.";
    } else{
        $firstname = $input_firstname;
    }
    
    $input_middlename = trim($_POST["middlename"]);
    if(empty($input_middlename)){
        $middlename_err = "Please enter a middle name.";
    } elseif(!filter_var($input_middlename, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
        $middlename_err = "Please enter a valid middle name.";
    } else{
        $middlename = $input_middlename;
    }

    $input_sirname = trim($_POST["sirname"]);
    if(empty($input_sirname)){
        $sirname_err = "Please enter a sir name.";
    } elseif(!filter_var($input_sirname, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
        $sirname_err = "Please enter a valid sir name.";
    } else{
        $sirname = $input_sirname;
    }

    $input_gender = trim($_POST["gender"]);
    if(empty($input_gender)){
        $gender_err = "Please enter a student gender.";
    } elseif(!filter_var($input_gender, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
        $gender_err = "Please enter a valid student gender.";
    } else{
        $gender = $input_gender;
    }

    $input_class = trim($_POST["class"]);
    if(empty($input_class)){
        $class_err = "Please enter class.";
    } elseif(!filter_var($input_class, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
        $class_err = "Please enter a valid class.";
    } else{
        $class = $input_class;
    }

    $input_stream = trim($_POST["stream"]);
    if(empty($input_stream)){
        $stram_err = "Please enter a stream.";
    } elseif(!filter_var($input_stream, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
        $stream_err = "Please enter a valid middle stream.";
    } else{
        $stream = $input_stream;
    }

    $input_dob = trim($_POST["dob"]);
    if(empty($input_dob)){
        $dob_err = "Please enter students date of birth date.";     
    } else{
        $dob = $input_dob;
    }

    $input_acc_year = trim($_POST["acc_year"]);
    if(empty($input_acc_year)){
        $acc_year_err = "Please enter the academic year.";     
    } elseif(!ctype_digit($input_acc_year)){
        $acc_year_err = "Please enter a positive integer value.";
    } else{
        $acc_year = $input_acc_year;
    }

    $input_por = trim($_POST["por"]);
    if(empty($input_por)){
        $por_err = "Please enter a student place of residence.";
    } elseif(!filter_var($input_por, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
        $por_err = "Please enter a valid student place of residence.";
    } else{
        $por = $input_por;
    }

    $input_day_boarding = trim($_POST["day_boarding"]);
    if(empty($input_day_boarding)){
        $day_boarding_err = "Please indicate wheter the student is in day or boarding.";
    } elseif(!filter_var($input_day_boarding, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
        $day_boarding_err = "Please enter a valid status.";
    } else{
        $day_boarding = $input_day_boarding;
    }

    $input_transport_zone = trim($_POST["transport_zone"]);
    if(empty($input_transport_zone)){
        $transport_zone_err = "Please enter a transport.";
    } elseif(!filter_var($input_transport_zone, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
        $transport_zone_err = "Please enter a valid transport.";
    } else{
        $transport_zone = $input_transport_zone;
    }

    $input_parentname1 = trim($_POST["parentname1"]);
    if(empty($input_parentname1)){
        $parentname1_err = "Please enter a student parent/gardian name.";
    } elseif(!filter_var($input_parentname1, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
        $parentname1_err = "Please enter a valid parent/gardian name.";
    } else{
        $parentname1 = $input_parentname1;
    }

    $input_contact1 = trim($_POST["contact1"]);
    if(empty($input_contact1)){
        $contact1_err = "Please enter the parent/gardian costact.";     
    } elseif(!ctype_digit($input_contact1)){
        $contact1_err = "Please enter a positive integer value.";
    } else{
        $contact1 = $input_contact1;
    }
    
    $input_parentname2 = trim($_POST["parentname2"]);
    if(empty($input_parentname2)){
        $parentname2_err = "Please enter a student parent/gardian name.";
    } elseif(!filter_var($input_parentname2, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
        $parentname2_err = "Please enter a valid parent/gardian name.";
    } else{
        $parentname2 = $input_parentname2;
    }

    $input_contact2 = trim($_POST["contact2"]);
    if(empty($input_contact2)){
        $contact2_err = "Please enter the parent/gardian costact.";     
    } elseif(!ctype_digit($input_contact2)){
        $contact2_err = "Please enter a positive integer value.";
    } else{
        $contact2 = $input_contact2;
    }
    
    
    // Check input errors before inserting in database
    if(empty($admin_no_err) && empty($firstname_err) && empty($middlename_err)&& empty($sirname_err)
    && empty($gender_err)&& empty($dob_err)&& empty($class_err) && empty($stream_err) && empty($acc_year_err)
    && empty($por_err) && empty($day_boarding_err) && empty($transport_zone_err) && empty($parentname1_err)
    && empty($contact1_err)&& empty($parentname2_err) && empty($contact2_err) ){
        // Prepare an update statement
        $sql = "UPDATE student SET firstname=?, middlename=?, sirname = ?, gender =?, dob =?, class = ?,
        stream=?, acc_year=?, por=?, day_boaring=?, transport_zone=?, parentname1=?,
        contact1=?, parentname2=?, contact2=? WHERE Id=?";
         
        if($stmt = mysqli_prepare($conn, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssssssssssssssssi", $param_admin_no, $param_firstname, $param_middlename, 
            $parma_sirname, $param_gender, $param_dob, $param_class, $param_stream, $param_acc_year,
            $param_por, $param_day_boaring, $param_transport_zone, $param_parentname1,$param_contact1,
            $param_contact2,$param_contact2, $param_id);
            
            // Set parameters
            $param_admin_no = $admin_no;
            $param_firstname = $firstname;
            $param_middlename = $middlename;
            $parma_sirname = $sirname;
            $param_gender = $gender;
            $param_dob = $dob;
            $param_class = $class;
            $param_stream = $stream;
            $param_acc_year = $acc_year;
            $param_por = $por;
            $param_day_boaring = $day_boarding;
            $param_transport_zone = $transport_zone;
            $param_parentname1 = $parentname1;
            $param_contact1 = $contact1;
            $param_parentname2 = $parentname2;
            $param_contact2 = $contact2;
            $param_id = $id;
            
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records updated successfully. Redirect to landing page
                header("location: student.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($conn);
} else{
    // Check existence of id parameter before processing further
    if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
        // Get URL parameter
        $id =  trim($_GET["id"]);
        
        // Prepare a select statement
        $sql = "SELECT * FROM student WHERE id = ?";
        if($stmt = mysqli_prepare($conn, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "i", $param_id);
            
            // Set parameters
            $param_id = $id;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                $result = mysqli_stmt_get_result($stmt);
    
                if(mysqli_num_rows($result) == 1){
                    /* Fetch result row as an associative array. Since the result set
                    contains only one row, we don't need to use while loop */
                    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                    
                    // Retrieve individual field value
                    
                    $firstname = $row["firstname"];
                    $middlename = $row["middlename"];
                    $sirname = $row["sirname"];
                    $gender = $row["gender"];
                    $dob = $row["dob"];
                    $class = $row["class"];
                    $stream = $row["stream"];
                    $acc_year = $row["acc_year"];
                    $por = $row["por"];
                    $day_boarding = $row["day_boarding"];
                    $parentname1 = $row["parentname1"];
                    $contact1 = $row["contact1"];
                    $parentname2 = $row["parentname2"];
                    $contact2 = $row["contact2"];

                } else{
                    // URL doesn't contain valid id. Redirect to error page
                    header("location: error.php");
                    exit();
                }
                
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
        
        // Close statement
        mysqli_stmt_close($stmt);
        
        // Close connection
        mysqli_close($conn);
    }  else{
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Record</title>
    
    <meta charset="UTF-8">
    <title>Addmission</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>

<!--  jQuery -->
<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>

<!-- Isolated Version of Bootstrap, not needed if your site already uses Bootstrap -->
<link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" />

<!-- Bootstrap Date-Picker Plugin -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script>
    $(document).ready(function(){
        var date_input=$('input[name="dob"]'); //our date input has the name "date"
        var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
        date_input.datepicker({
            format: 'mm/dd/yyyy',
            container: container,
            todayHighlight: true,
            autoclose: true,
        })
    })

    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>

<script type="text/javascript">
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();   
        });
    </script>  

</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Update Record</h2>
                    </div>
                    <p>Please edit the input values and submit to update the record.</p>
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">

                    <div class="form-group">
                            <label>First Name</label>
                            <input type="text" name="firstname" class="form-control <?php echo (!empty($firstname_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $firstname; ?>">
                            <span class="invalid-feedback"><?php echo $firstname_err;?></span>
                        </div>
                        <div class="form-group">
                            <label>Middle Name</label>
                            <input type="text" name="middlename" class="form-control <?php echo (!empty($middlename_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $middlename; ?>">
                            <span class="invalid-feedback"><?php echo $middlename_err;?></span>
                        </div>
                        <div class="form-group">
                            <label>Sir Name</label>
                            <input type="text" name="sirname" class="form-control <?php echo (!empty($sirname_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $sirname; ?>">
                            <span class="invalid-feedback"><?php echo $sirname_err;?></span>
                        </div>
                        <div class="form-group">
                            <label>Gender</label>
                                <select name="gender" required class="form-control">
							        <option value="">Select</option>
							        <option value="Male">Male</option>
							        <option value="Female">Female</option>
					            </select>
                        </div>
                        <div class="form-group">
                            <label>Date of birth</label>
                            <input class="form-control"  id="dob" name="dob" placeholder="MM/DD/YYY" type="date"/>
                            
                        </div>
                        <div class="form-group">
                            <label>Class</label>
                            <select name="class" required class="form-control">
							         <option value="">Select</option>
                                     <option value="BC">Baby class</option>
                                     <option value="PREP 1">Prep 1</option>
							         <option value="PREP 2">Prep 2</option>
							         <option value="Class 1">Class 1</option>
                                     <option value="Class 2">Class 2</option>
                                     <option value="Class 3">Class 3</option>
                                     <option value="Class 4">Class 4</option>
                                     <option value="Class 5">Class 5</option>
                                     <option value="Class 6">Class 6</option>
                                     <option value="Class 7">Class 7</option>
					        </select> 
                        </div>
                        <div class="form-group">
                            <label>Stream</label>
                            <select name="stream" required class="form-control">
							         <option value="">Select</option>
                                     <option value="A">A</option>
                                     <option value="B">B</option>
							         <option value="C">C</option>
							         <option value="Blue">Blue</option>
                                     <option value="Green">Green</option>
                                     <option value="Yellow">Yellow</option>
                                     <option value="Orange">Orange</option>
					        </select> 
                        </div>
                        <div class="form-group">
                            <label>Accademic Year</label>
                            <input type="text" name="acc_year" class="form-control <?php echo (!empty($acc_year_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $acc_year; ?>">
                            <span class="invalid-feedback"><?php echo $acc_year_err;?></span>
                        </div>
                        <div class="form-group">
                            <label>Place of residence</label>
                            <select name="por" required class="form-control">
							         <option value="">Select</option>
                                     <option value="Bukoba">Bukoba</option>
                                     <option value="Mwanza">Mwanza</option>
							         <option value="Geita">Geita</option>
							         <option value="Kahama">Kahama</option>
                                     <option value="Sengerema">Sengerema</option>
                                     <option value="Shinyanga">Shinyanga</option>
					        </select> 
                        </div>
                        <div class="form-group">
                            <label>Day or Boarding</label>
                            <select name="day_boarding" required class="form-control">
							        <option value="">Select</option>
							        <option value="Day">Day</option>
							        <option value="Bording">Boarding</option>
					            </select>
                        </div><div class="form-group">
                            <label>Transport</label>
                                 <select name="transport_zone" required class="form-control">
							         <option value="">Select</option>
                                     <option value="Not on trnsport">Not on transport</option>
							         <option value="ZONE A">ZONE A</option>
							         <option value="ZONE B">ZONE B</option>
                                     <option value="ZONE C">ZONE C</option>
                                     <option value="ZONE D">ZONE D</option>
					            </select> 
                        </div><div class="form-group">
                            <label>Parent/Gardian 1</label>
                            <input type="text" name="parentname1" class="form-control <?php echo (!empty($parentname1_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $parentname1; ?>">
                            <span class="invalid-feedback"><?php echo $parentname1_err;?></span>
                        </div><div class="form-group"><div class="form-group">
                            <label>Contact</label>
                            <input type="text" name="contact1" class="form-control <?php echo (!empty($contact1_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $contact1; ?>">
                            <span class="invalid-feedback"><?php echo $contact1_err;?></span>
                        </div><div class="form-group">
                        <div class="form-group">
                            <label>Parent/Gardian 2</label>
                            <input type="text" name="parentname2" class="form-control <?php echo (!empty($parentname2_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $parentname2; ?>">
                            <span class="invalid-feedback"><?php echo $parentname2_err;?></span>
                        </div><div class="form-group">
                        <div class="form-group">
                            <label>Contact</label>
                            <input type="text" name="contact2" class="form-control <?php echo (!empty($contact_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $contact2; ?>">
                            <span class="invalid-feedback"><?php echo $contact2_err;?></span>
                        </div><div class="form-group">
                        


                        <input type="hidden" name="Id" value="<?php echo $id; ?>"/>

                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="attendence.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>