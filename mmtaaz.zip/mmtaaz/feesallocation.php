<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script src="tableExport/tableExport.js"></script>
    <script type="text/javascript" src="tableExport/jquery.base64.js"></script>
    <script src="js/export.js"></script>

    <style>
        .wrapper{
            width: 900px;
            margin: 0 auto;
        }
        table tr td:last-child{
            width: 120px;
        }
    </style>
    <script>
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();   
        });
    </script>

</script>

<script type="text/javascript">
function exportToExcel(tableID, filename = ''){
    var downloadurl;
    var dataFileType = 'application/vnd.ms-excel';
    var tableSelect = document.getElementById(tableID);
    var tableHTMLData = tableSelect.outerHTML.replace(/ /g, '%20');
    
    // Specify file name
    filename = filename?filename+'.xls':'export_excel_data.xls';
    
    // Create download link element
    downloadurl = document.createElement("a");
    
    document.body.appendChild(downloadurl);
    
    if(navigator.msSaveOrOpenBlob){
        var blob = new Blob(['\ufeff', tableHTMLData], {
            type: dataFileType
        });
        navigator.msSaveOrOpenBlob( blob, filename);
    }else{
        // Create a link to the file
        downloadurl.href = 'data:' + dataFileType + ', ' + tableHTMLData;
    
        // Setting the file name
        downloadurl.download = filename;
        
        //triggering the function
        downloadurl.click();
    }
}
 
</script>

</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="mt-5 mb-3 clearfix">
                        <h3 class="pull-left">Student Details</h3>
                        <a href="feesAdd.php" class="btn btn-success pull-right" target="content" ><i class="fa fa-plus"></i> Allocate Student Fees</a>
                    </div>
                    <?php
                    // Include config file
                    require_once "config.php";
                    
                    // Attempt select query execution
                    $sql = "SELECT * FROM feesallocation";
                    if($result = mysqli_query($conn, $sql)){
                        if(mysqli_num_rows($result) > 0){
                            echo "<table Id='fees' class='table table-bordered table-striped'>";
                                echo "<thead>";
                                    echo "<tr>";
                                        echo "<th>Allocation Date</th>";
                                        echo "<th>Accademic year</th>";
                                        echo "<th>Admision no</th>";
                                        echo "<th>Registration Fees</th>";
                                        echo "<th>School Fees</th>";
                                        echo "<th>Transport</th>";
                                        echo "<th>Examination</th>";
                                        echo "<th>Uniform</th>";
                                        echo "<th>Truck Suit</th>";
                                        echo "<th>Stream</th>";
                                        echo "<th>School Trip</th>";
                                        echo "<th>Food</th>";
                                        echo "<th>Medical</th>";
                                        
                                        echo "<th>Action</th>";
                                    echo "</tr>";
                                echo "</thead>";
                                echo "<tbody>";
                                while($row = mysqli_fetch_array($result)){
                                    echo "<tr>";
                                        echo "<td>" . $row['allocation_date'] . "</td>";
                                        echo "<td>" . $row['acc_year'] . "</td>";
                                        echo "<td>" . $row['admin_no'] . "</td>";
                                        echo "<td>" . $row['registration'] . "</td>";
                                        echo "<td>" . $row['schoolfees'] . "</td>";
                                        echo "<td>" . $row['transport'] . "</td>";
                                        echo "<td>" . $row['examination'] . "</td>";
                                        echo "<td>" . $row['uniform'] . "</td>";
                                        echo "<td>" . $row['trucksuit'] . "</td>";
                                        echo "<td>" . $row['schooltrip'] . "</td>";
                                        echo "<td>" . $row['food'] . "</td>";
                                        echo "<td>" . $row['medical'] . "</td>";
                                        echo "<td>" . $row['total'] . "</td>";
                                        
                                        echo "<td>";
                                            echo '<a href="studentread.php?id='. $row['id'] .'" target="content" class="mr-3" title="View Record" data-toggle="tooltip"><span class="fa fa-eye" ></span></a>';
                                            echo '<a href="studentupdate.php?id='. $row['id'] .'" target="content"  class="mr-3" title="Update Record" data-toggle="tooltip"><span class="fa fa-pencil"></span></a>';
                                            echo '<a href="studentdelete.php?id='. $row['id'] .'" target="content"  title="Delete Record" data-toggle="tooltip"><span class="fa fa-trash"></span></a>';
                                        echo "</td>";
                                    echo "</tr>";
                                }
                                echo "</tbody>";                            
                            echo "</table>";
                            // Free result set
                            mysqli_free_result($result);
                        } else{
                            echo '<div class="alert alert-danger"><em>No records were found.</em></div>';
                        }
                    } else{
                        echo "Oops! Something went wrong. Please try again later.";
                    }
 
                    // Close connection
                    mysqli_close($conn);
                    ?>
                </div>
            </div>        
        </div>
    </div>
    <div>
<button onclick="exportToExcel('fees', 'fees')" class="btn btn-primary">Export To Excel</button>
</div>
<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
<script>
$(document).ready(function() {
    $('#fees').DataTable();
} );
</script>
</body>
</html>