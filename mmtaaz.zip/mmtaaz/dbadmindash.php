<?php
//ession_start();
//Include database connection file
include_once('config.php');
//if (!isset($_SESSION['ID'])) {
    //header("Location:dbadminlogin.php");
    //exit();
//}
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

/* Create two unequal columns that floats next to each other */
.column {
  float: left;
  padding: 10px;
  height: 500px; /* Should be removed. Only for demonstration */
}

.left {
  width: 20%;
}

.right {
  width: 80%;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Header/Logo Title */
.header {
  padding: 20px;
  text-align: center;
  background: #1abc9c;
  color: white;
  font-size: 15px;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  width: 220px;
  background-color: #aaa;
  
}

li a {
  display: block;
  color: #000;
  padding: 8px 16px;
  text-decoration: none;
  
}

li a:hover:not(.active) {
  background-color: #555;
  color: white;
}

.dropdown {
  float: left;
  overflow: hidden;
  text-decoration: none;
}

.dropdown .dropbtn {
  font-size: 19px;  
  border: none;
  outline: none;
  color: black;
  padding: 0px 15px;
  background-color: inherit;
  
  margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: #555;
  color: white;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #aaa;
  min-width: 250px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: #aaa;
}

.dropdown:hover .dropdown-content {
  display: block;background-color: #555;
  color: white;

}

</style>
</head>
<body>
<div class="header">
  <h1>MUMTAAZ ENGLISH MEDIUM DAY & BOARDING PRE & PRIMARY SCHOOL MANAGEMENT SYSTEM.</h1>
  
</div>



<div class="row">
  <div class="column left" style="background-color:#aaa;">  
<ul>
  <h3><li><a href="feesallocationAdd.php" target="content">Users</a></li></h3>
  <h3><div class="dropdown">
          <li class="dropbtn">Student Management
              <i class="fa fa-caret-down"></i>
          </li></br>
          <div class="dropdown-content">
              <a href="student.php" target="content">Student</a>
              <a href="classes.php" target="content">Class allocation</a>
          </div>
      </div></h3></br></br>

      <h3><div class="dropdown">
          <li class="dropbtn">Fees Management 
              <i class="fa fa-caret-down"></i>
          </li></br>
          <div class="dropdown-content">
              <a href="fees.php" target="content">Fees Allocation</a>
              <a href="feespaymentAdd1.php" target="content">Fees Payment</a>
              <a href="#" target="content">Payment Statment</a> 
              <a href="#" target="content">Opening balances</a> 
              <a href="#" target="content">Balance Check</a>
          </div>
      </div></h3></br></br>
      <h3><div class="dropdown">
          <li class="dropbtn">Accounting
              <i class="fa fa-caret-down"></i>
          </li></br>
          <div class="dropdown-content">
              <a href="student.php" target="content">Other Incomes</a>
              <a href="classes.php" target="content">General Income</a>
              <a href="classes.php" target="content">Expenditures</a>
              <a href="classes.php" target="content">Opening balances</a>
              <a href="classes.php" target="content">Ledgers</a>
          </div>
      </div></h3></br></br>
      <h3><div class="dropdown">
          <li class="dropbtn">Food Store
              <i class="fa fa-caret-down"></i>
          </li></br>
          <div class="dropdown-content">
              <a href="student.php" target="content">Store ledger</a>
              <a href="classes.php" target="content">Balance Check</a>
          </div>
      </div></h3></br></br>
      <h3><div class="dropdown">
          <li class="dropbtn">General Store
              <i class="fa fa-caret-down"></i>
          </li></br>
          <div class="dropdown-content">
              <a href="student.php" target="content">Store ledger</a>
              <a href="classes.php" target="content">Balance Check</a>
          </div>
      </div></h3></br></br>

      <h3><li><a href="logout.php" target="content" >Logout</a></li></h3>
       
</ul>
  </div>
  <div class="column right" id="content" style="background-color:#bbb;">
  <iframe name="content" src="start.html" width="100%" height="100%"allowTransparency="true"  frameborder="0"  ></iframe>
  </div>
</div>

</body>
</html>
