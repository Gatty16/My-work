<?php

require_once "config.php";
 
$admin_no = $firstname =$middlename =$sirname= $acc_year= $paydate= $receiptdate=
$paymethod= $receiptno= $registration= $schoolfees= $transport= $examination= $uniform= 
$tracksuit= $schooltrip= $food= $medical="";

if(isset($_REQUEST["term"])){
    // Prepare a select statement
    $sql = " SELECT * FROM student WHERE firstname LIKE ?";
    if($stmt = mysqli_prepare($conn, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "s", $param_term);
        
        // Set parameters
        $param_term = $_REQUEST["term"] . '%';
        
        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
            $result = mysqli_stmt_get_result($stmt);
            
            // Check number of rows in the result set
            if(mysqli_num_rows($result) > 0)
            {
              while ($row = mysqli_fetch_array($result))
              {
                  ?>
                <form method="post"
                style ="margin: auto;width: 450px;max-width: 100%;background: #ffffff; border-radius: 3px; margin-top:5px"
                >

                <br>
                <div>
                    <lable>Admission No:</lable>
                    <input type="text" name="admin_no" readonly value="<?php echo $row['admin_no'];?>">
                </div></br>
                <div>
                    <lable>First Name:</lable>
                    <input type="text" name="firstname" readonly  value="<?php echo $row['firstname'];?>">
                </div></br>
                <div>
                    <lable>Middle Name:</lable>
                    <input type="text" name="middlename" readonly value="<?php echo $row['middlename'];?>">
                </div><br>
                <div>
                   <lable>Sir Name:</lable>
                   <input type="text" name="sirname" readonly value="<?php echo $row['sirname'];?>">
                </div><br>
                <div>
                    <lable>Accademic Year:</lable> 
                    <input type="text" name="acc_year" id = "acc_year"  value="<?php echo $acc_year; ?>">
                </div><br>
                <div>
                <div>
                    <label  class="control-label" for="paydate">Paymentment Date</label>
                    <input class="form-control" id="paydate" name="paydate" placeholder="MM/DD/YYY" type="date"/>
                </div><br>
                <div>
                    <label  class="control-label" for="receiptdate">Receipt Date</label>
                    <input class="form-control" id="receiptdate" name="receiptdate" placeholder="MM/DD/YYY" type="date"/>
                </div><br>
                <div>
                    <lable>Paymentment Method:</lable> 
                    <select name="paymethod" id="paymethod" required class="form-control">
						<option value="">Select</option>
                        <option value="AMANA">AMANA</option>
						<option value="CRDB-EXTERNA">CRDB EXTERNAL</option>
						<option value="CRDB-MUMTAAZ">CRDB MUMTAAZ</option>
                        <option value="NMB">NMB</option>
                        <option value="LETSHEGO">LETSHEGO</option>
                        <option value="KBC">KBC</option>
                        <option value="M-PESA">M-PESA</option>
					</select>
                </div><br>
                <div>
                    <lable>Receipt No:</lable> 
                    <input type="text" id = "receiptno" name="receiptno" class="form-control" value="<?php echo $receiptno; ?>">
                </div><br>
                <div>
                    <lable>Registration Fees:</lable> 
                    <input type="text" id = "registration" name="registration" class="form-control" value="<?php echo $registration; ?>">
                </div><br>
                <div>
                    <lable>School Fess:</lable> 
                    <input type="text" id = "schoolfees" name="schoolfees" class="form-control" value="<?php echo $schoolfees; ?>">
                </div><br>
                <div>
                    <lable>Transport Fess:</lable> 
                    <input type="text" id = "transport" name="transport" class="form-control" value="<?php echo $transport; ?>">
                </div><br>
                <div>
                    <lable>Examination Fess:</lable> 
                    <input type="text" id = "examination" name="examination" class="form-control" value="<?php echo $examination; ?>">
                </div><br>
                <div>
                    <lable>Unform:</lable> 
                    <input type="text" id = "uniform" name="uniform" class="form-control" value="<?php echo $uniform; ?>">
                </div><br>
                <div>
                    <lable>Tracksuit:</lable> 
                    <input type="text" id = "tracksuit" name="tracksuit" class="form-control" value="<?php echo $tracksuit; ?>">
                </div><br>
                <div>
                    <lable>School Trip:</lable> 
                    <input type="text" id = "schooltrip" name="schooltrip" class="form-control" value="<?php echo $schooltrip; ?>">
                </div><br>
                <div>
                    <lable>Food:</lable> 
                    <input type="text" id = "food" name="food" class="form-control" value="<?php echo $food; ?>">
                </div><br>
                <div>
                    <lable>Medical Fess:</lable> 
                    <input type="text" id = "medical" name="medical" class="form-control" value="<?php echo $medical; ?>">
                </div><br>
                  
        <input type="submit" name="submit" id = "submit" value="submit" class="btn-primary pull-right" onClick = "return empty()"> <br>

</form>
<?php
            }  
            }
            
            // if the id not exist
            // show a message and clear inputs
            else {
                echo "Undifined name";
                    $firstname = "";
                    
            }
            
            
            mysqli_free_result($result);
            mysqli_close($conn);
            
        }
        
        } 
        else{
           echo "error " . $sql . "  " . mysqli_error($conn);
        }
        
    }
   
?>






