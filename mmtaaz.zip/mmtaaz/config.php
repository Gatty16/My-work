<?php

$dbServername = "localhost";
$dbUsername = "root";
$dbpassword = "";
$dbName = "mumtz";

$conn = mysqli_connect($dbServername, $dbUsername,$dbpassword,$dbName);
?>