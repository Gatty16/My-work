<?php
require_once "config.php";
        
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $acc_year = $_POST["acc_year"];
            $admin_no = $_POST["admin_no"];
            $class = $_POST["class"];
            $stream = $_POST["stream"];
           
            if (!$conn)
            {
                die("Connection failed: " . mysqli_connect_error());
            }
            $admin_no= $_POST['admin_no'];
			$s="SELECT * FROM classes WHERE admin_no = '$admin_no' AND acc_year = '$acc_year'";
			$res=$conn->query($s);
				if($res->num_rows>0)
					{
						echo "<div class='error'>Insert Failed student ready exist or the admission no is taken</div>";
					}
                    else
					{
                        $sql = "INSERT INTO classes (acc_year, admin_no,class,stream)
                        VALUES ('$acc_year', '$admin_no','$class','$stream')";
                        if (mysqli_query($conn, $sql)) {
                            header("location: student.php");
                        } else {
                            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
                        }
                        mysqli_close($conn);          
					}    
        }
?>
 
<html>
<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

</head>
<body>
<div class="container">
<div class="row">
    <div class="col-md-12">
        <form action="<?php echo ($_SERVER["PHP_SELF"]);?>" method="post">
            <div align="left">
              <h3>Allocate student class</h3>
            </div></br>
            <div align="left">
                <label>Accademic Year</label>
                <input type="text"  class="form-control" name="acc_year" id="acc_year">
            </div>
            <div align="left">
             <label>Admision No</label>
            <input type="text" class="form-control" name="admin_no" id="admin_no">
            </div>            
            <div align="left">
                <label>Class</label>
                    <select name="class" id="class" required class="form-control">
						<option value="">Select</option>
                        <option value="BC">Baby class</option>
                        <option value="PREP 1">Prep 1</option>
						<option value="PREP 2">Prep 2</option>
						<option value="Class 1">Class 1</option>
                        <option value="Class 2">Class 2</option>
                        <option value="Class 3">Class 3</option>
                        <option value="Class 4">Class 4</option>
                        <option value="Class 5">Class 5</option>
                        <option value="Class 6">Class 6</option>
                        <option value="Class 7">Class 7</option>
					</select> 
            </div>
            <div align="left">
                <label>Stream</label>
                    <select name="stream" id="stream" required class="form-control">
						 <option value="">Select</option>
                         <option value="A">A</option>
                         <option value="B">B</option>
						 <option value="C">C</option>
						 <option value="Blue">Blue</option>
                         <option value="Green">Green</option>
                         <option value="Yellow">Yellow</option>
                         <option value="Orange">Orange</option>
					</select> 
            </div>
             
                <input type="submit" class="btn btn-primary" value="Submit">
                <a href="student.php" class="btn btn-secondary ml-2">Cancel</a>
            </div>
        </form>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script></div>
</div>
</div>
</body>
</html>