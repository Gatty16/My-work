<?php
require_once "config.php";      
?>
 
<?php
	$no="MUMTAAZ1001";
	$sql="select * from student order by ID desc limit 1";
	$res=$conn->query($sql);
	    if($res->num_rows>0)
			{
				$row1=$res->fetch_assoc();
				$no=substr($row1["admin_no"],1,strlen($row1["admin_no"]));
				$no++;
				$no="M".$no;
			}
?>
<?php
        require_once "config.php";
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $admin_no = $_POST["admin_no"];
            $firstname = $_POST["firstname"];
            $middlename = $_POST["middlename"];
            $sirname = $_POST["sirname"];
            $gender = $_POST["gender"];
            $dob = $_POST["dob"];
            $class = $_POST["class"];
            $stream = $_POST["stream"];
            $acc_year = $_POST["acc_year"];
            $por = $_POST["por"];
            $day_boarding = $_POST["day_boarding"];
            $transport_zone = $_POST["transport_zone"];
            $parentname1 = $_POST["parentname1"];
            $contact1 = $_POST["contact1"];
            $parentname2 = $_POST["parentname2"];
            $contact2 = $_POST["contact2"];

            if (!$conn)
            {
                die("Connection failed: " . mysqli_connect_error());
            }
            $sql = "INSERT INTO student (admin_no, firstname, middlename, sirname, gender,dob,class,
            stream,acc_year,por, day_boarding, transport_zone, parentname1, contact1, parentname2, contact2)
            VALUES ('$admin_no','$firstname','$middlename','$sirname','$gender','$dob','$class',
            '$stream','$acc_year','$por','$day_boarding','$transport_zone','$parentname1',
            '$contact1','$parentname2','$contact2')";
            if (mysqli_query($conn, $sql)) {
                header("location: student.php");
            } else {
                echo "Error: " . $sql . "<br>" . mysqli_error($conn);
            }
            mysqli_close($conn);
        }
?>
 
<html>
<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<script>
    $(document).ready(function(){
        var date_input=$('input[name="dob"]'); //our date input has the name "date"
        var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
        date_input.datepicker({
            format: 'mm/dd/yyyy',
            container: container,
            todayHighlight: true,
            autoclose: true,
        })
    })
</script>
</head>
<body>
<div class="container">
<div class="row">
    <div class="col-md-12">
        <form action="<?php echo ($_SERVER["PHP_SELF"]);?>" method="post">
            <div align="left">
              <h3>Add new student</h3>
            </div></br>
            <div align="left">
             <label>Admision No</label>
            <input type="text" class="form-control" name="admin_no" id="admin_no" style="color: red" value="<?php echo $no; ?>" readonly>
            </div>
            <div align="left">
                <label>First Name</label>
                <input type="text" class="form-control" name="firstname" id="firstname">
            </div>
            <div align="left">
                <label>Middle Name</label>
                <input type="text"  class="form-control" name="middlename" id="middlename">
            </div>
            <div align="left">
                <label>Sir Name</label>
                <input type="text"  class="form-control" name="sirname" id="sirname">
            </div>
            <div align="left">
                <label>Gender</label>
                    <select name="gender" id="gender" required class="form-control">
						<option value="">Select</option>
						<option value="Male">Male</option>
						<option value="Female">Female</option>
					</select>
            </div>
            <div align="left">
                <label>Date of Birth</label>
                <input class="form-control"  id="dob" name="dob" placeholder="MM/DD/YYY" type="date"/>
            </div>
            <div align="left">
                <label>Class</label>
                    <select name="class" id="class" required class="form-control">
						<option value="">Select</option>
                        <option value="BC">Baby class</option>
                        <option value="PREP 1">Prep 1</option>
						<option value="PREP 2">Prep 2</option>
						<option value="Class 1">Class 1</option>
                        <option value="Class 2">Class 2</option>
                        <option value="Class 3">Class 3</option>
                        <option value="Class 4">Class 4</option>
                        <option value="Class 5">Class 5</option>
                        <option value="Class 6">Class 6</option>
                        <option value="Class 7">Class 7</option>
					</select> 
            </div>
            <div align="left">
                <label>Stream</label>
                    <select name="stream" id="stream" required class="form-control">
						 <option value="">Select</option>
                         <option value="A">A</option>
                         <option value="B">B</option>
						 <option value="C">C</option>
						 <option value="Blue">Blue</option>
                         <option value="Green">Green</option>
                         <option value="Yellow">Yellow</option>
                         <option value="Orange">Orange</option>
					</select> 
            </div>
            <div align="left">
                <label>Accademic Year</label>
                <input type="text"  class="form-control" name="acc_year" id="acc_year">
            </div>
            <div align="left">
                <label>Place of resident</label>
                     <select name="por" id="por" required class="form-control">
						 <option value="">Select</option>
                         <option value="Bukoba">Bukoba</option>
                         <option value="Mwanza">Mwanza</option>
						 <option value="Geita">Geita</option>
						 <option value="Kahama">Kahama</option>
                         <option value="Sengerema">Sengerema</option>
                         <option value="Shinyanga">Shinyanga</option>
					 </select> 
            </div>
            <div align="left">
                <label>Day or Boarding</label>
                    <select name="day_boarding" id="day_boarding" required class="form-control">
						<option value="">Select</option>
						<option value="Day">Day</option>
						<option value="Bording">Boarding</option>
					</select>
            </div>
            <div align="left">
                <label>Transport zone</label>
                    <select name="transport_zone" id="transport_zone" required class="form-control">
						 <option value="">Select</option>
                         <option value="Not on transport">Not on transport</option>
						 <option value="ZONE A">ZONE A</option>
						 <option value="ZONE B">ZONE B</option>
                         <option value="ZONE C">ZONE C</option>
                         <option value="ZONE D">ZONE D</option>
					</select> 
            </div>
            <div align="left">
                <label>First Parent/Gardian</label>
                <input type="text"  class="form-control" name="parentname1" id="parentname1">
            </div>
            <div align="left">
                <label>Contact</label>
                <input type="text"  class="form-control" name="contact1" id="contact1">
            </div>
            <div align="left">
                <label>Seconf Parent/Gardian</label>
                <input type="text"  class="form-control" name="parentname2" id="parentname2">
            </div>
            <div align="left">
                <label>Contact</label>
                <input type="text"  class="form-control" name="contact2" id="contact2">
            </div>
            </br>
            <div align="left">
                
                <input type="submit" class="btn btn-primary" value="Submit">
                <a href="student.php" class="btn btn-secondary ml-2">Cancel</a>
            </div>
        </form>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script></div>
</div>
</div>
</body>
</html>