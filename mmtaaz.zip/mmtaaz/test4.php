<?php
require_once "config.php";
 

// Define variables and initialize with empty values


if (isset($_POST['submit'])){
		
$admin_no = $_POST['admin_no'];
$acc_year = $_POST['acc_year'];
$paydate = $_POST['paydate'];
$receiptdate = $_POST['receiptdate'];
$paymethod = $_POST['paymethod'];
$receiptno = $_POST['receiptno'];
$registration = $_POST['registration'];
$schoolfees = $_POST['schoolfees'];
$transport = $_POST['transport'];
$examination = $_POST['examination'];
$uniform = $_POST['uniform'];
$tracksuit = $_POST['tracksuit'];
$schooltrip = $_POST['schooltrip'];
$food = $_POST['food'];
$medical = $_POST['medical'];

        // Prepare an insert statement
        $sql = "INSERT INTO feespayment (admin_no,acc_year,paydate,receiptdate,paymethod,receiptno,registration,
        schoolfees,examination,uniform,tracksuit,schoolltrip,food,medical) 
        VALUES ('$admin_no','$acc_year','$paydate','$receiptdate','$paymethod','$receiptno','$registration',
        '$schoolfees','$transport','$examination','$uniform','$tracksuit','$schooltrip','$food','$medical')";
    
    if (mysqli_query($conn, $sql)) {
      header("location: student.php");
      } 
    else 
      {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
      }
     
    // Close connection
    mysqli_close($conn);

}


?>


